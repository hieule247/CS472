package lehieule.miu.edu;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Quiz {
    private List<Question> listQuestion;

    private int idxQuest;
    private int curScore;
    // Constructor
    public Quiz (){
        this.listQuestion = Arrays.asList(
            new Question("3, 1, 4, 1, 5", "9"),
            new Question("1, 1, 2, 3, 5", "8"),
            new Question("1, 4, 9, 16, 25", "36"),
            new Question("2, 3, 5, 7, 11", "13"),
            new Question("1, 2, 4, 8, 16", "32")
        );
        // Collections.shuffle(this.listQuestion);
        this.idxQuest = -1;
    }
    // Get nextQuestion()
    public String getNextQuestion(){
        if (this.idxQuest >= listQuestion.size() - 1)
            return null;
        else {
            this.idxQuest++;
            Question nextQuest = listQuestion.get(this.idxQuest);
            return  nextQuest.getQuestion();
        }
    }
    // checkAnswer()
    public void checkAnswer(String answer){
        Question curQuest = listQuestion.get(this.idxQuest);
        if (curQuest.checkAnswer(answer))
            this.curScore++;
    }
    // getScore()
    public int getScore(){
        return this.curScore;
    }
    // getTotalsScore()
    public int getTotalScore(){
        return this.listQuestion.size();
    }
}
