package lehieule.miu.edu;

public class Question {
    private final String question;
    private final String answer;

    public Question(String question, String answer){
        this.question = question;
        this.answer = answer;
    }

    public String getQuestion(){
        return this.question;
    }

    public boolean checkAnswer(String answer) {
        return this.answer.equals(answer);
    }
}
